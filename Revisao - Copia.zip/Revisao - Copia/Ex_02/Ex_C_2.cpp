
        #include <iostream>
        # include <iomanip>
        using namespace std;

        int main (){
            int a,b,c;
            int resultado;
            resultado = a + b * c;

            cout << "Digite os valores: ";
            cin >> a >> b >> c;

            cout << "O resultado é " << resultado;



            return 0;
        }