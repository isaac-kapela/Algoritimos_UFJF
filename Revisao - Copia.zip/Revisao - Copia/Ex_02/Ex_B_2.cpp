
        #include <iostream>
        # include <iomanip>
        using namespace std;

        int main (){

            int a,c,d;
            int resultado;
            cout << "Digite os valores solicitados";
            cin >> a >> c >> d;
            resultado =  d%a - c;

            cout << "o resultado é " << resultado;




            
        return 0;
        
        }