    
        #include <iostream>
        # include <iomanip>
        using namespace std;

        int main (){ 

            float a,b,c,d;
            float resultado1;
            
            
            cout << "Digite os valores solicitados: ";
            cin >> a >> b >> c >> d ;
            resultado1 = a/b + d*c;
          //  resultado2 =  d*c;
         //   resultado_final = resultado1 + resultado2;
            
            cout << "O resulatdo da expressão é : " << resultado1;

        



            return 0;
        }